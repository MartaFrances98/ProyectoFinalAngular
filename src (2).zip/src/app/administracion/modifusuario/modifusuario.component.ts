import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { ValidacionesPropias } from '../../validaciones-propias';
import { Router } from '@angular/router';
import { SignupService } from '../../servicios/singup/signup.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { UsuariosService } from '../../servicios/usuarios/usuarios.service';


@Component({
  selector: 'app-modifusuario',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterOutlet, HttpClientModule],
  templateUrl: './modifusuario.component.html',
  styleUrl: './modifusuario.component.css',
  providers: [SignupService, UsuariosService],

})
export class ModifusuarioComponent {
  usuarios: any[] = [];
  constructor(private ruta: Router, private authService: SignupService, private usuariosService: UsuariosService) { }

  resultado = '';
  opcionesParaMostrar: Array<{ id: string; nombre: string; }> = [];
  formularioContacto = new FormGroup({
    Miembros: new FormControl([]),
    DNI: new FormControl('', [Validators.required, ValidacionesPropias.formatoDNI]),
    nombre: new FormControl('', [Validators.required, Validators.pattern("[A-Z]*"), Validators.maxLength(20)]),
    apellido: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    mail: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.maxLength(4)]),
    sexo: new FormControl('s/n'),
    administrador: new FormControl(''),
    horario: new FormControl('Mañana'),
    edad: new FormControl('', [Validators.min(10), Validators.max(85)]),
    test: new FormGroup({
      pregunta1: new FormControl(''),
      pregunta2: new FormControl(''),
      pregunta3: new FormControl('')
    })
  });

  // actualizarFormularioConUsuario(userId: string) {
  //   const usuarioSeleccionado = this.usuarios.find(u => u.id === userId);

  //   // Si encontramos un usuario, rellenamos el formulario con sus datos
  //   if (usuarioSeleccionado) {
  //     this.formularioContacto.patchValue({
  //       DNI: usuarioSeleccionado.DNI,
  //       nombre: usuarioSeleccionado.nombre,
  //       apellido: usuarioSeleccionado.apellido,
  //       sexo: usuarioSeleccionado.sexo,
  //       administrador: usuarioSeleccionado.administrador,
  //       horario: usuarioSeleccionado.horario,
  //       edad: usuarioSeleccionado.edad,
  //       test: {
  //         pregunta1: '',
  //         pregunta2: '',
  //         pregunta3: ''
  //       }
  //     });
  //   }
  // }

  verEdad(edad: any) {
    return parseInt(edad.value)
  }

  edadMenorA16(): boolean {
    const edadControl = this.formularioContacto.get('edad');
    if (edadControl && edadControl.value) {
      const edad = +edadControl.value;
      return edad < 16;
    }
    return false;
  }

  submit(event: Event) {
    event.preventDefault();
    if (this.formularioContacto.valid) {
      const userData = this.formularioContacto.value;
      this.usuariosService.updateUser(userData).subscribe({
        next: (response) => {
          console.log('Modificación exitosa', response);
          alert('¡Modificación exitosa!');
          this.ruta.navigate(['/dashboard']);
        },
        error: (error: HttpErrorResponse) => {
          console.error('Error al modificar el usuario', error);
          this.resultado = 'Error al modificar el usuario. Por favor, inténtelo de nuevo.';
        }
      });
    } else {
      console.error('El formulario no es válido');
      this.resultado = 'Por favor, completa el formulario correctamente.';
    }
  }
  // submit(event: Event) {
  //   event.preventDefault();
  //   if (this.formularioContacto.valid) {
  //     const userData = this.formularioContacto.value; 
  //     this.authService.registerUser(userData).subscribe({
  //       next: (response) => {
  //         console.log('Modificacion exitosa', response);
  //         alert('¡Modificacion exitosa!');
  //         // this.ruta.navigate(['/login']);
  //       },
  //       error: (error) => {
  //         console.error('Error al modificar el usuario', error);
  //         this.resultado = 'Error al modificar el usuario. Por favor, inténtelo de nuevo.';
  //       }
  //     });

  //   } else {
  //     console.error('El formulario no es válido');
  //     this.resultado = 'Por favor, completa el formulario correctamente.';
  //   }
  // }

  volverAlDashboard() {
    this.ruta.navigate(['/dashboard']);
  }
  ngOnInit() {
    this.cargarUsuarios();
  }

  cargarUsuarios() {
    this.usuariosService.getUsuarios().subscribe({
      next: (response) => {
        if (response.success && Array.isArray(response.users)) {
          this.opcionesParaMostrar = response.users.map((usuario: any) => ({
            id: usuario.DniUsuario,
            nombre: `${usuario.Nombre} ${usuario.Apellido}`
          }));
          // Si necesitas inicializar las opciones seleccionadas, puedes hacerlo aquí
          // Por ejemplo, si quieres pre-seleccionar todos:
          this.opcionesParaMostrar.map(opcion => opcion.id);
        } else {
          console.error("Se esperaba un array de usuarios, pero se recibió:", response);
        }
      },
      error: (error) => {
        console.error('Error al obtener los usuarios', error);
      }
    });
  }
  actualizarFormularioConUsuario(event: Event) {
    let selectElement = event.target as HTMLSelectElement; 
    
    if (selectElement && selectElement.value) {
      let userId = selectElement.value;
      console.log(userId)
      if (!userId) return; 

      this.usuariosService.getUser(userId).subscribe({
        next: (usuario) => {
          this.formularioContacto.patchValue({
            DNI: usuario.DNI,
            nombre: usuario.nombre,
            apellido: usuario.apellido,
            mail: usuario.mail,
            sexo: usuario.sexo,
            administrador: usuario.administrador,
            horario: usuario.horario,
            edad: usuario.edad,
            
          });
        },
        error: (error) => {
          console.error('Error al obtener el usuario', error);
        },
      });
    } else {
      console.error('El elemento seleccionado es nulo o no tiene valor');
    }
  }

}
