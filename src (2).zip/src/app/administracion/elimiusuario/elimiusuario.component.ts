import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UsuariosService } from '../../servicios/usuarios/usuarios.service';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-elimiusuario',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './elimiusuario.component.html',
  styleUrl: './elimiusuario.component.css',
  providers: [UsuariosService],
})
export class ElimiusuarioComponent {
  users: any[] = [];
  selectedUserid: String = '';
  selectedUser: any;
  opcionesParaMostrar: Array<{ id: string; nombre: string; mail: string; }> = [];
  constructor(private ruta: Router, private usuariosService: UsuariosService) { }

  ngOnInit() {
    this.usuariosService.getUsuarios().subscribe({
      next: (response) => {
        if (response.success && Array.isArray(response.users)) {
          this.opcionesParaMostrar = response.users.map((usuario: any) => ({
            id: usuario.DniUsuario,
            nombre: usuario.Nombre,
            mail: usuario.Mail
          }));
          this.opcionesParaMostrar.map((opcion: any) => opcion.id);
        } else {
          console.error("Se esperaba un array de usuarios, pero se recibió:", response);
        }
      },
      error: (error) => {
        console.error('Error al obtener los usuarios', error);
      }
    });
  }

  selectUserForDeletion(id: any) {
    this.selectedUserid = id;
    this.selectedUser = this.opcionesParaMostrar.find((user) => user.id === id);
  }

  deleteUser() {
    if (!this.selectedUser) {
      console.error('No hay un usuario seleccionado para eliminar');
      return;
    } else {
      this.usuariosService.deleteUser(this.selectedUserid).subscribe({
        next: (response) => {
          console.log('Usuario eliminado con éxito', response);
          this.ngOnInit(); // Recarga los usuarios
        },
        error: (error) => {
          console.error('Error al eliminar el usuario', error);
        },
      });
    }
  }


  volverAlDashboard() {
    this.ruta.navigate(['/dashboard']);
  }
}



